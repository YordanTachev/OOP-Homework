﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPhomework
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Goalkeeper player1 = new Goalkeeper { Name = "Jake", Number = 6, Age = 15, Height = 180 };
            Defender player2 = new Defender { Name = "Gosho", Number = 4, Age = 18, Height = 184 };
            Midfielder player3 = new Midfielder { Name = "Tom", Number = 13, Age = 12, Height = 178 };
            Striker player4 = new Striker { Name = "Petur", Number = 83, Age = 20, Height = 189 };

            Coach coach = new Coach { Name = "Alexsandur", Age = 40 };

            Team team1 = new Team { Coach = coach, Players = new List<FootballPlayer> { player1, player2, player3, player4 } };

            Goalkeeper player5 = new Goalkeeper { Name = "Ivan", Number = 11, Age = 17, Height = 192 };
            Defender player6 = new Defender { Name = "Petur", Number = 44, Age = 16, Height = 170 };
            Midfielder player7 = new Midfielder { Name = "Tosho", Number = 98, Age = 14, Height = 183 };
            Striker player8 = new Striker { Name = "Dobromir", Number = 67, Age = 19, Height = 196 };

            Team team2 = new Team { Coach = coach, Players = new List<FootballPlayer>() };
        }
    }
}
