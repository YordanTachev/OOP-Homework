﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPhomework
{
    internal class Game
    {
        public Team Team1 { get; set; }
        public Team Team2 { get; set; }
        public Referee Referee { get; set; }
        public List<Tuple<int, FootballPlayer>> Goals { get; set; }

        public Game()
        {
            Goals = new List<Tuple<int, FootballPlayer>>();
        }

        public void AddGoal(int minute, FootballPlayer player)
        {
            Goals.Add(new Tuple<int, FootballPlayer>(minute, player));
        }

        public string GetResult()
        {
            int team1Goals = Goals.Count(goal => Team1.Players.Contains(goal.Item2));
            int team2Goals = Goals.Count(goal => Team2.Players.Contains(goal.Item2));

            if (team1Goals > team2Goals)
            {
                return $"{Team1.Coach.Name}'s team won";
            }
            else if (team2Goals > team1Goals)
            {
                return $"{Team2.Coach.Name}'s team won";
            }
            else
            {
                return "It's a draw";
            }
        }
    }
}
